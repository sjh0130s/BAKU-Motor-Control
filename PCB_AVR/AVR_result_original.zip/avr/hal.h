#ifndef HAL_H
#define HAL_H
#include <stdint.h>
#include <stdbool.h>
/* SPI: PD7=ETH_CS, PB1=CAN_CS, PB2=hardware SS (output HIGH).
 * PB3=MOSI, PB4=MISO, PB5=SCK. PD2/PB0 are interrupt inputs.
 * PD3/PD4 are unused mode switch inputs with external pull-ups. */
typedef struct {
    uint32_t id;
    uint8_t len, data[8];
    bool extended, remote;
} CanFrame;
void board_init(void);
uint32_t millis(void);
void delay_ms(uint16_t ms);
void log_text(const char *text);
void log_auto(int32_t raw, int32_t limited, int16_t rpm);
bool ethernet_init(void);
/* 1 = one complete datagram consumed, 0 = none, -1 = hardware/protocol fault.
 * len is original payload length. At most capacity bytes are copied. */
int8_t udp_receive(uint8_t ip[4], uint8_t *data, uint8_t capacity, uint16_t *len);
bool can_init(void);
bool can_receive(CanFrame *frame);
bool can_send(uint32_t id, const uint8_t data[8]);
#endif
